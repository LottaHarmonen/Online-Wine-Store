﻿namespace webbutveckling_labb2_LottaHarmonen.Shared.DTOs;

public class CustomerLogInDTO
{
    public string Email { get; set; }

    public string Password { get; set; }

}