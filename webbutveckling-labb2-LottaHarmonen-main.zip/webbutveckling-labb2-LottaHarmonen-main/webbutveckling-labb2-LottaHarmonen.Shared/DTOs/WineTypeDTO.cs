﻿namespace webbutveckling_labb2_LottaHarmonen.Shared.DTOs;

public class WineTypeDTO
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
}