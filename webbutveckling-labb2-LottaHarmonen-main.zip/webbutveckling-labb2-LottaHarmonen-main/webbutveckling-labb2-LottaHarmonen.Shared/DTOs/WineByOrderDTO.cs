﻿namespace webbutveckling_labb2_LottaHarmonen.Shared.DTOs;

public class WineByOrderDTO
{

    public string Name { get; set; }

    public int Price { get; set; }

    public String Type { get; set; }

}